/**
 * 
 */
package com.tax;

import java.math.BigDecimal;
import java.math.RoundingMode;

/**
 * @author Alakka
 *
 */
public class Product {
	private static final double LUXURY_TAX_RATE = 1.09;
	private static final double NECESSITIES_TAX_RATE = 1.01;

	private double cost;
	private Boolean isLuxury;

	public Product() {
		cost = 0;
		isLuxury = false;
	}

	public void setCost(double inputCost) {

		cost = inputCost;
	}

	public double getCost() {

		return cost;
	}

	public void setIsLuxury(Boolean inputIsLuxury) {

		isLuxury = inputIsLuxury;
	}

	public Boolean getIsLuxury() {

		return isLuxury;
	}

	public double calculatePriceAfterTax() {
		if (this.isLuxury) {
			if (this.cost * LUXURY_TAX_RATE >= Double.MAX_VALUE) {
				return Double.MAX_VALUE;
			}
			return this.roundValueToPennies((this.cost * LUXURY_TAX_RATE));
		}
		if (this.cost * NECESSITIES_TAX_RATE >= Double.MAX_VALUE) {
			return Double.MAX_VALUE;
		}
		return this.roundValueToPennies(this.cost * NECESSITIES_TAX_RATE);
	}

	public double roundValueToPennies(double input) {
		BigDecimal value = new BigDecimal(input);
		return value.setScale(2, RoundingMode.HALF_EVEN).doubleValue();
	}

}
