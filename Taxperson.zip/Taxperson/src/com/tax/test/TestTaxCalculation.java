/**
 * 
 */
package com.tax.test;

import static org.junit.Assert.*;

import org.junit.Test;

import com.tax.Product;

/**
 * @author Alakka
 *
 */
public class TestTaxCalculation {
	@Test
	public void testLuxuryTaxCalculation() {
		Product product = new Product();
		double cost = 10.01;
		product.setCost(cost);
		product.setIsLuxury(true);
		double luxuryTaxRate = 1.09;
		double expectedValue = product.roundValueToPennies(cost * luxuryTaxRate);
		assertTrue(expectedValue == product.calculatePriceAfterTax());
	}

	@Test
	public void testNecessityTaxCalculation(){
		Product product = new Product();
		double cost = 21.12;
		product.setCost(cost);
		product.setIsLuxury(false);
		double necessityTaxRate = 1.01;
		double expectedValue = product.roundValueToPennies(cost * necessityTaxRate);
		assertTrue(expectedValue == product.calculatePriceAfterTax());
		
	}

}
