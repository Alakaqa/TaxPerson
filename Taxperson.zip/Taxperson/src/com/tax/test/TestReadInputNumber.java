/**
 * 
 */
package com.tax.test;

import static org.junit.Assert.*;

import org.junit.Test;

import com.tax.TaxCalculator;

/**
 * @author Alakka
 *
 */
public class TestReadInputNumber {
	
	@Test
	public void testBadInputRejection(){
		assertTrue(-1.0 == TaxCalculator.readCostInput("hello"));
	}
	
	@Test
	public void testIntegerInput(){
		assertTrue(-1.0 != TaxCalculator.readCostInput("130"));
	}
	
	@Test
	public void testNegativeInputRejection(){
		assertTrue(-1.0 == TaxCalculator.readCostInput("-12.04"));
	}
		
	@Test
	public void testOutOfRangeValueResolution(){
		assertTrue(-1.0 == TaxCalculator.readCostInput("1241.002342"));
	}
	

}
