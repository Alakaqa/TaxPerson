/**
 * 
 */
package com.tax;

import java.util.Scanner;

/**
 * @author Alakka
 *
 */
public class TaxCalculator {
	
	@SuppressWarnings("resource")
	public static void main(String[] args) {		
		
		Scanner scanner = new Scanner(System.in);
		double initPrice = -1.0;
		String isLuxuryInput = "";		
		
		
		do {
			System.out
					.println("Please input the price of the product as an integer or floating point number with two decimals");
			initPrice = readCostInput(scanner.nextLine());
		} while (initPrice == -1.0);

		do {
			System.out
					.println("Please input 'yes' if this is a luxury product?");
			isLuxuryInput = scanner.nextLine();
		} while (!(isLuxuryInput.toLowerCase().matches("yes") || isLuxuryInput.toLowerCase()
				.matches("no")));
		
		Product product = new Product();
		product.setIsLuxury(readLuxuryStatus(isLuxuryInput));
		product.setCost(initPrice);

		System.out.println("Product cost is: "
				+ product.calculatePriceAfterTax());
	}

	
	public static double readCostInput(String costInput) {

		if (costInput.matches("\\d+\\.\\d")
				|| costInput.matches("\\d+\\.\\d\\d")
				|| costInput.matches("\\d+")) {
			return Double.parseDouble(costInput);
		}
		return -1.0;
	}
	
	public static Boolean readLuxuryStatus(String isLuxuryInput) {

		if (isLuxuryInput.toLowerCase().matches("yes")) {
			return true;
		}
		return false;
	}

}
